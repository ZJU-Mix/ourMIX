ACLLib
======
ACLLib is a bunch of C functions covers Win32API and provides simpler API to beginners for programming Windows GUI applications. It compiles with MinGW and MS Visual Studio Express.

Document
======
https://github.com/wengkai/ACLLib/wiki
